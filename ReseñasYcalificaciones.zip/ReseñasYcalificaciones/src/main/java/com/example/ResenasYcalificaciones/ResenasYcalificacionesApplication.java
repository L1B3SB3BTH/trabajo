package com.example.ResenasYcalificaciones;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ResenasYcalificacionesApplication {

	public static void main(String[] args) {
		SpringApplication.run(ResenasYcalificacionesApplication.class, args);
	}

}
