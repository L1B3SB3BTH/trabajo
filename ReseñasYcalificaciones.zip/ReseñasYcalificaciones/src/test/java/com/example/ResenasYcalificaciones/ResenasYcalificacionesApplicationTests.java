package com.example.ResenasYcalificaciones;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ResenasYcalificacionesApplicationTests {

	@Test
	void contextLoads() {
	}

}
