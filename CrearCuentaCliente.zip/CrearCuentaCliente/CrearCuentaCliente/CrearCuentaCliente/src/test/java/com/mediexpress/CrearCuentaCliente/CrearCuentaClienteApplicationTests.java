package com.mediexpress.CrearCuentaCliente;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrearCuentaClienteApplicationTests {

	@Test
	void contextLoads() {
	}

}
