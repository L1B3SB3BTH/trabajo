package com.mediexpress.CrearCuentaCliente.Service;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mediexpress.CrearCuentaCliente.model.Cliente;
import com.mediexpress.CrearCuentaCliente.repository.ClienteRepositorio;

@Service
public class ClienteServicio {
    @Autowired
    private ClienteRepositorio repositorio;

    // Registrar cliente directamente)
    public Cliente registrar(Cliente cliente) {
        return repositorio.save(cliente);
    }

    // Buscar cliente por email
    public Optional<Cliente> buscarPorEmail(String email) {
        return repositorio.findByEmail(email);
    }

    // Buscar cliente por ID
    public Optional<Cliente> buscarPorId(Long id) {
        return repositorio.findById(id);
    }
    
}
