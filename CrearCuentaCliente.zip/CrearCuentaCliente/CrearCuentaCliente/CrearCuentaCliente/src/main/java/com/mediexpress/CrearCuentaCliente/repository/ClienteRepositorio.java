package com.mediexpress.CrearCuentaCliente.repository;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import com.mediexpress.CrearCuentaCliente.model.Cliente;

public interface ClienteRepositorio extends JpaRepository<Cliente, Long> {
    Optional<Cliente> findByEmail(String email);
}
    


